import network

# Activer le Wi-Fi en mode station
wlan = network.WLAN(network.STA_IF)
wlan.active(True)

# Scanner les réseaux disponibles
networks = wlan.scan()

# Affichage des réseaux trouvés
print("Réseaux Wi-Fi disponibles :")
for net in networks:
    ssid = net[0].decode()  # Nom du réseau (SSID)
    bssid = ':'.join(f'{b:02x}' for b in net[1])  # Adresse MAC (BSSID)
    channel = net[2]  # Canal Wi-Fi
    rssi = net[3]  # Puissance du signal (RSSI)
    security = net[4]  # Type de sécurité (0: ouvert, 1: WEP, 2: WPA-PSK, 3: WPA2-PSK, 4: WPA/WPA2-PSK)

    print(f"SSID: {ssid}, BSSID: {bssid}, Canal: {channel}, Signal: {rssi}dBm, Sécurité: {security}")
