'''
Contrôle d'un écran couleur ST7735 avec un Raspberry Pi Pico

Plus d'infos:
https://electroniqueamateur.blogspot.com/2021/05/ecran-couleur-spi-st7735-et-raspberry.html

'''

from ST7735 import TFT   # https://github.com/boochow/MicroPython-ST7735
from sysfont import sysfont # https://github.com/GuyCarver/MicroPython/blob/master/lib/sysfont.py
from machine import SPI,Pin

backlight = Pin(2, Pin.OUT)
backlight.high() 

#spi = machine.SPI(0, baudrate=8000000, polarity=0, phase=0, sck=Pin(18), mosi=Pin(19), miso=Pin(16))
#lcd = ST7735.ST7735(spi, rst=6, ce=17, dc=3)

spi = SPI(0, baudrate=80000000, polarity=0, phase=0, sck=Pin(18), mosi=Pin(19), miso=Pin(16))
tft=TFT(spi,3,6,17) # AO: GP 3, RST : GP 6, CS : GP 17
tft.initr()
tft.rgb(True) # essayer False si mauvaises couleurs

tft.rotation(3)  # portrait (0 ou 2)  ou paysage (1 ou 3)

tft.fill(TFT.BLACK)  # fond noir

# écriture de texte
tft.text((18, 15), "Demonstration ST7735", TFT.WHITE, sysfont, 1)

# tracé d'une ligne droite
tft.line((20, 35),(140, 35), TFT.GREEN)  # point de départ, point d'arrivée, couleur

#tracé d'un rectangle plein
tft.fillrect((20,50), (50, 50), TFT.BLUE) # point de départ, largeur, hauteur, couleur

# tracé d'un contour de rectangle
tft.rect((20,50), (50, 50), TFT.CYAN) # point de départ, largeur, hauteur, couleur

# réglage d'un pixel individuel (petit point au centre du carré
tft.pixel((45,75), TFT.WHITE)

# tracé d'un cercle plein
tft.fillcircle((120, 73), 25, TFT.RED)

# tracé d'un contour de cercle
tft.circle((120, 73), 25, TFT.YELLOW)

# réglage d'un pixel individuel (petit point au centre du cercle
tft.pixel((120, 73), TFT.WHITE)