from ST7735 import TFT,TFTColor
from machine import SPI,Pin
spi = SPI(0, baudrate=80000000, polarity=0, phase=0, sck=Pin(18), mosi=Pin(19), miso=Pin(16))
tft=TFT(spi,3,6,17) # AO: GP 3, RST : GP 6, CS : GP 17
tft.initr()
tft.rgb(True)
tft.fill(TFT.BLACK)
backlight = Pin(2, Pin.OUT)
backlight.high()
print("OK")
f=open('car1.bmp', 'rb')
if f.read(2) == b'BM':  #header
    print("File ok")
    dummy = f.read(8) #file size(4), creator bytes(4)
    offset = int.from_bytes(f.read(4), 'little')
    hdrsize = int.from_bytes(f.read(4), 'little')
    width = int.from_bytes(f.read(4), 'little')
    height = int.from_bytes(f.read(4), 'little')
    if int.from_bytes(f.read(2), 'little') == 1: #planes must be 1
        depth = int.from_bytes(f.read(2), 'little')
        if depth == 24 and int.from_bytes(f.read(4), 'little') == 0:#compress method == uncompressed
            print("Image size:", width, "x", height)
            rowsize = (width * 3 + 3) & ~3
            if height < 0:
                height = -height
                flip = False
            else:
                flip = True
            w, h = width, height
            if w > 128: w = 128
            if h > 160: h = 160
            tft._setwindowloc((0,0),(w - 1,h - 1))
            for row in range(h):
                if flip:
                    pos = offset + (height - 1 - row) * rowsize
                else:
                    pos = offset + row * rowsize
                if f.tell() != pos:
                    dummy = f.seek(pos)
                for col in range(w):
                    bgr = f.read(3)
                    tft._pushcolor(TFTColor(bgr[2],bgr[1],bgr[0]))
#spi.deinit()