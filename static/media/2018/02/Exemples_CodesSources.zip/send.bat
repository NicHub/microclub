echo ampy -p COM7 run test1.py
ampy -p COM7 run --no-output dht11.py
echo ampy -p COM7 run --no-output dht11pix.py
echo ampy -p COM7 run test1.py