import dht
#from machine import Pin
import machine
import time
import neopixel

teta = 0

def display(np):
    n = np.n
    for j in range(n):
        np[j] = (int(teta), 255-int(teta), 0)
        np.write()

print("init")
d = dht.DHT22(machine.Pin(5))
np = neopixel.NeoPixel(machine.Pin(4), 24)

for c in range(0,100):
   print("mesure %d :" %c)
   d.measure()
   t = d.temperature()
   h = d.humidity()
   teta = (t-20)*40
   if teta > 255 :
       teta = 255
   print("Temperature = %3.2fC, Humidity = %3.2f  %d" %(t,h,teta))
   
   display(np)
   time.sleep(1)