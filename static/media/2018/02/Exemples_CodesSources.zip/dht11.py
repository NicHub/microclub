import dht
#from machine import Pin
import machine
import time
print("init")
d = dht.DHT22(machine.Pin(5))

for c in range(0,100):
   print("mesure %d :" %c)
   d.measure()
   t = d.temperature()
   h = d.humidity()
   print("Temperature = %3.2fC, Humidity = %3.2f" %(t,h))
   time.sleep(1)