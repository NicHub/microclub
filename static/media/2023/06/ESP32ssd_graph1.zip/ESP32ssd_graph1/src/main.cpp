#include <Arduino.h>
#include <U8g2lib.h>

U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE, /* clock=*/ 22, /* data=*/ 21);

void setup() 
{
  u8g2.begin();
}

void loop() 
{
  u8g2.firstPage();
  do {
    u8g2.setFont(u8g2_font_ncenB14_tr);
    u8g2.drawStr(0,15,"Microclub");
    u8g2.drawCircle(20, 35, 10, U8G2_DRAW_ALL);
    u8g2.drawFrame(80,30,25,15);
  } while ( u8g2.nextPage() );
  delay(1000);
}
