/**
 *  @file         MicroClubDemo.ino
 *  @version      0.1
 *  @date         Octobre 2016
 *  @author       Laurent FRANCEY (l.francey@franic.eu)
 *  @author       Nhu-Hoai Robert VO (von@franic.eu)
 *  @copyright    Franic Technologies SA
 *  @brief        Démo ESP8266 avec carte MULTOUT MC23017
 */

//
// Raccordements : nodemcu SCL=D1 SDA=D2 
//
 
//
//  Chargement des librairies nécessaires
//

#include <ESP8266WiFi.h>
#include <DNSServer.h>
#include <ESP8266WebServer.h>
#include "Wire.h"


//
//  Constantes et variables globales
//

/// Nom du réseau WiFi
const char *SSID = "Microclub";

/// Adresse IP de l'ESP8266
IPAddress SERVER_IP(192, 168, 1, 1);

/// Port du serveur DNS
const byte DNS_PORT = 53;

/// Serveur DNS
DNSServer DNS_SERVER;

/// Port du serveur web
const byte WEB_PORT = 80;

/// Serveur web
ESP8266WebServer WEB_SERVER(WEB_PORT);

/// Variables relais MULTOUT
unsigned char VRelais8,VRelais16;

//
//  Méthodes
//


/**
 *  Initialisation, configuration du MCP23017
 */
void InitMCP23017(unsigned char adresse, unsigned char gpioadr, unsigned char configP)
{
  Wire.beginTransmission(adresse);
  Wire.write(gpioadr);    // 0=portA, 1 = portB
  Wire.write(configP);     // 0=output, 1 = input
  Wire.endTransmission();
}

/**
 *  Ecriture de la valeur d'un port 8bits sur le MCP23017
 */
void EcritMultout(unsigned char adresse, unsigned char gpioadr, unsigned char MsbVal, unsigned char LsbVal)
{
  Wire.beginTransmission(adresse);
  Wire.write(gpioadr);
  Wire.write(LsbVal);
  Wire.write(MsbVal);
  Wire.endTransmission();
}

/**
 *  Vue HTML à la racine
 */
void handleRoot() {
  // Code HTML simpliste avec code javascript pour des requêtes AJAX
	String html = "<html><head><meta charset=\"UTF-8\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" /><title>Microclub</title><style>"
        "body{font-family:calibri,arial,sans-serif;text-align:center;}"
        "table{margin:0 auto;}"
        "#logo{max-width:400px;width:100%;}"
        "input[type=checkbox]{transform:scale(2);}"
        "</style></head><body>"
        "<div id=\"header\"><img id=\"logo\" src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZAAAACWCAIAAAB/80kyAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4AoFEjYpc/IntgAAIABJREFUeNrtnXl8VNXZx3/nzpKVhKxkYUuQNUCEAIIoAoILiqJQtK0giOJWF1oX3kJRQBCxlbYiLrUIgoqIWkGsqERACJQECBDCkpAAWTCZJCSTmSwzc+95/8hNJjOZnUkyCc/3kz8yd557znnO8puz3XvY7HWzP/llM0QJBEEQvgxjSgDoGiJOHAmJNIsgCB/Wq8JSpfyvwMAZ5QhBED6sWBAoEwiC6CiQYBEEQYJFEARBgkUQBAkWQRCEr6N0+w7GIDAA4BwSpxwkCMITAQE82P7psmAxgDGcLcGlMlypAQcCVIgPw4AYBPvTvlOCIJyJjQJ5GuRrUK6DxKFWIiYU/bohsgtMoothKJLvSj5ZepYnxoPb7y4pBKTnY2sGjpfEK0Nu7D18UERicB27fDALhy+ivAoJkVBc3ehSwWCUkFOFKgNiAmz03QQGgSFXiyoDogJspJYBagHnqqCpRZgflAJaOuSvwCUdLtci1A8qewZ6FOmhFBCigtjCwk+B8npc1EHB0NXPhoFKgN6EvGqIEiL9YeI2PBU5crSoFREdYMNAYODAuSpcqUd0oF1Pc7WoqEdUgO389Ffgog4lDj0trkVpDQKV8FfayHB/BTR1uKSDSkCo2ranOiPyqsGAcD8bjhBEk1SdvozPDyO9ONTAbuqVMiS6b7jkX5h+AocLcEmDnuHwVzvvNWn1LvSwJI5P0lCom//A/KXzlsaExzT/8l87/vXcP56rfW8PZo5CTIin/gh45xR2F5kb5B8GY0IcTI0dN7WATbn4Ms98y0N9MSMBBskcwk9FWHfKbHBbdzwxyByCwHCiAm+dgM4oX7kpBs8OtkhGgR6vHcWVevlj31AsHoaAZll0pR7LjqJIL3+MDcSSFET4mQ2MEpYdRVaF/DFYhT8PQ98Qs14IDG+fwp5i+WOAEguGYHikWS/UAj46h28umMOc0w/Teps9VQnYcRHrz5oNpifgob4wSmZBPKzBWyfMV27shgVDzcLHgPNarD6OikZPh0fihaFQNvvJKavDsqP4tUb+2D0IS1LQtVmVqjHhzeM4dUX+GBOIl5MRH0Rtk7DR3fn6KE5ppk6euuqJVYN6D2r+5Vf7vnr2788W/esA7h6MgbFOZ5nY7HWzPzm5XZw0yvawTmDYcIBV1R5bfyz5umSbQXDwEY+OOJp9FLNHIyLYbX/UApYcwYly6+tPJ2F8LDggMHx0FjsvWRvMTMTMPpA4GJBajHezrQ2GR+Ivw+V2e64Ki9OtDRJDsGYM6kUA0NTh6f3WBgFKbBxvFqNZP9vI0I8nwF8hS8ncPag0WBv8dTR6Bsu9s4X/w+lKa4MlwzE4HACUDG+fws/F1ga/7YP7E8E5GPDdJXx0ztrgjh54bIDcCTpWhtczW3jaBWtulD29XIPn0qwNovzx/jhZ32tMmLPHRrdu00SoBfn/R/ai2mht88HN6OpHLZSw6It8eQTnyr9888v7b7nfntXMJTO/+O8XmD4UfaIdqVVhicNxnMDwYzZKa3K35NpTKwAM7MiHRwb1GYSt6WDuP99zrsqGWgF4NxtqBQDojDbUCsDWPBhEWSlaqhWAo2U4r5VHN38/acMgT4sDv8rZ+sFpGwa1JnyZDwYIDJtybMv/hrPyJOJ/L9lQKwDvnYZKAIAjGhtqBWDNSVnyNHU21ArAZ+flqDlsqBWA7wtQXg8AAQq8Yysr8qqRrpHz6p1TNgw0dfj+klzoG8/Z/F3C5hwIDAz4Mt+GWjV4qqQHvIjmbfASTpd/9/Z3DtQKwNZlW6dNnoZvTqDO6Dg8h4JVXYcjRWv+tCYxLtFpwvav2w+9iEPn4W6NPVJmdyiaUwUA/yt1cu/ZSicGWiPK6uxkaDkEBrWA4+V2QtBAJUAt2E3GYQ3UApQC0u04klslt/OjdgyqjSitAyBrik0yywHYTSSAw6UAUFIHrcGOp2VggELAuSrbBhllUApQCzissRuFSoDKvsHRMvk3hiAAMIafz8yZPufOG+50avv1yq+DgoOw+7R5DdE9wWIMGRdVwarnZz7vStrCuoQ9Nv0xHLkApTtVlsH2b3UDDbNFlfV2DRpkqEBv16BhEHSx2q5BsR4K5mjBobhGnu+/YicZOiMEBgVDgc5uIDUmKAQU1dg1aLjXQVaU1sqJsUfD3NylakchKBiq6h2lQcEgMOjtJKOiHgoGBTPP4tksUIJoIKsQNfjHc/9w0XzVE6uQXQqj6JFgKQWcL511+yzXk/fIXY9AK6FE65YIN73WZvz48RqNJjMzMySkcfI+zA8A/OVp7379+hUUFOTm5sbFxckGXVQAmuZNIiIisrKySkpKxowZYx7VAghWyZ8EITU1taKiYsqUKbJBsAoSb76Itm3bNp1O9+KLL5rTIAGcw08W4lWrVun1+jfeeMM8B8cBiTfNST/55JPV1dU7d+60aMacw0/O7dtuu628vHzv3r1KZeOMfsO9atkgOTm5qKjo3LlzZk9DVQAQIkcRExNz+vTpCxcu9O/fXzZoSF6jgUqlOnjwYEVFxeTJk63T2fSb9vXXWq121qxZzTzl8qQhAOD999/X6/VvvvmmbBCkhMQhAaFyLAsWLNDpdOvXr7cYORIEAIWAXE3K8JSQIFfX4ubdPQ9G4HypR4LFgbK6MUljXE/h6KTREAFNtWcO/uc//4mMjExOTl6zZo2F3Kjk9vPZZ5917969T58+mzZtMjdCmBvYmjVrkpKSoqOjd+zYYRFCI4sXL54wYUJYWFgLNZH/nTFjxvTp04OCglavXh0VFSXnOzi4HFdycvLLL78cGBj40ksvjRw5EgDUCrmDxliDUqxbty44OHjKlCmPP/64dZYCAHbt2hUeHj5u3Ljly5db/0gAALZs2RIXF9e3b98PP/xQ/kqlANA0Q/Thhx8OGDCgV69eX331VaOBRVEuXbp09OjRYWFhP/zwg83cfvTRR6dNm9alS5ePP/5YpVI1pR/gDZ6OGTNm/vz5gYGBL7zwwuDBg2VP5XQyANHR0W+99VZQUNDcuXPvvfdeaqGEpbQwlFePHTLW9TsC/AJCY0JRpvNIsAwmSIgIjXAvlSo4nTazh8lkkmM2GCzGF43tXBRFK0urYUjTjeYQLGkKwa7TzW6UY2EWctM8avl/yz6F1Ow9iPX1tsdfvHEEap2exutGo9FFR8whcNsG3M5o10ZWNHkqWaTBRoa3CMFpxhLX3gQWUGeMCHFPQKJCo1BndLB2Z1+w1AowaPVa91JpBPyUnjl4++23nz17NjU1dcGCBfIlvUmeAAIAzJw58/Tp08eOHTOPYhomfRqnmZ9//vl9+/adO3fujjvuaGxJEgB5MRFYsWLFzp07i4qKJk2a1MyANbXV7du3v//++xcvXnz00UevXLkCANUGMAbGGiaJTp069corr5SXl7/66qvHjh0DAL1RftpAZ2xour/97W8LCws//vjjDRs2WJRf497LSZMmFRcX7969e8mSJY1KKQFAnZzO6dOnZ2dnHzp06JFHHpENGnxsnOSaN2/eiRMncnNz77vvPtmgztQ8hFdfffWHH34oKCi45ZZbbCraRx999PXXX5eWls6ePVvWplpRfp7BIALIyMhYuXLl5cuXFy5ceObMGTkNjIEBWiOA8vLyZ555pqys7IMPPvj222+phRLW4wm1skpf5dZNlfpKqJUOZhbsiwtjCFOln0l/+M6HXYzsZN5JCEB4sPtSDABHjhwZMGCAxTcNjbCxnV+4cGHQoEGWPSIJaJxZB3Q6nbl9Ng+8zvz7f/fdd9sIoRlPPPGExef6hmZsvrBs2bJly5ZZR8LMsWzZsmXLli3WmQnWtJMzNTU1Pj7eOhaYJ5hycnKSkpJspLNRecvKypKTLTeaNORSnampy3P77bfb6L41c/f++++3zm3LX7ZFixYtWrTIIgoGgDUlY+3atWvXrrXdTSOucSSO8KCMMxluSBznZUVlGBntYCbUfg/LJCEhavMPm12Pb/OuzQgE4kLdkWEub6q0yYgoAEjoYtdgSDgApETZNYgLBCBvy7TJ0HB5t2TjxLw1KVEwSDBJdpPRJwRGCQYJKZG2DfwUCFTCJCEpzG4yGlLYy35WDItw4khiCAAk2++BDwiDyBHlb3fZOCUSBgkmju52NqwnhcEowShiqJ1YIvzpAR3CPHZJiNr3v32i5Op0wac/fgoBSIjyaA6LcwzvWaWp+uynz1yagRJNqz9djeQeNh46c8ytcXabaMP64KhoBNrqCXYLQN9QAAj3Q/+utrqPAm6JlcV+bIztWCZ3lzs403rbNri3FyQOg4R77BsYJUgcU3vZMegtd3xu627bYGyM3P25MQYBtjaF9O6CHsEA0DcU0bYeHgxUYmQUAAgMo+zsFZ4cL3c2p/SwbXBnT3AOg4j7Emwb3JcAowSTfU+n9mzqfBEEhnaHAos+WOSi+UvvvoQ+XRHk55FgAYgOwcDIWa/NcmUma8qLU8CBm/s62tNkb+y5YqT1xXA/vHy93PcxSnjjBhtTbCtGyiMpo4QlwxHUQtRWjZIHWSLHgiGICbQ2+PMw+S4OzEi00T2Z2w+9GztWE2JldbNo5D0wLlb+Pz4I8wdaGwwKw+/6yF3cICX+PMzaIDYQC4bIKm+U8HoLTwMUeDVF9rRexMqRTbsfzKOw1TfI402R44WhiPK3DmTJcHkZUeKYN0AW+uY8nYTYxvy5NR4T4mzIblMXckg4HuhjbTAqCtMSaFsD0azHoMCNCW+sf+NU/imnti+880JxUTEmDXL86hdnzxJKHP/aG+EXeubTM5GhkfZCefCVBz//7nM8OAw9Izz0TW/C1vPI1cJfgZQo3NPL/NyyPIkjYmsesivBgOsjMCPRerqEAd9cwLFyGCX064oZCdb9MqWA7y4hrQT1Inp2wQOJiPCzaGBqAXsv45dfcaUe3YNwV0/0CbHoMKoEHC3DfwtQUYcIf0zpiesjzM8YA1Aw5Ovw7UUU6hDqh5u6YUKcxTQZA8rrsDUPuVoEqTC2G6b0tPa0TsS2PJytgoIhOQL39bbR+d2Wj8xycCCpK2b2sdrTAAXDzkvI0KBWRGIXTE9EmNrCU5WA3UXYcxnaevQKwfTe6B5s8eCRSkC6BqlF0NQhJgC398DgcIt0KhnOVGH7BRTVIMIPt3XHjd1aTggS17xmCdiYJlypObb+2NA+Q+1ZLd+wfMnbS3BbX6T0dtDjYYUlzgQLQJ0RH6ehxvj35//+3G+es/oy7WTaQ689lH8hH/cOQf+Yq3qlH2NQMnBYN+Dmrb1hp5JJsvtLrnLBgAEm+28fVDIIzLmByO0Ofhs2vnNud0JHaPTU6MxT41VkhVKQlybtOiJAYDBJdg0a9rU78LTBQLJfZATBgU8PoVj30tyXVsxfoVRYdCNyCnPmrJyTdjgNtyRgbF8n3SuXBKuBH7ORWQwlbht9W1JikkqhKtQU7jq8q/xyOeICcc/1CAtyezBIEMS1gELAgRyk5cOEm0bdNKzvsED/wNIrpXsz9+bl5CFchbuGoGeE83fLuCFYAoPegBMFuFSOylqIEoL9EBuKAbHoHen48R+CIK51GINJxMlC5JehQg+jiEA1orugbzf0j3XxjaOssMTlTZ4SR4AKNyTixusa3+kOiBI4J7UiCMLZwJBDIeD6nkjpbRYQSYLEXX8/Mjw5hEKUQAJFEIRnXJ2A0DFfBEF0GEiwCIIgwSIIgiDBIgiCBIsgCIIEiyAIggSLIAgSLIIgCBIsgiAIEiyCIEiwCIIgSLAIgiBIsAiCIMEiCIIgwSIIgiDBIgiiU6JsrYAZrI9yIQji2sHB2SU+J1gqQdhxiaUWg85SIYhrEt49UHp8AAK8rDCtIljsSBlbfwYKBjpXkyCuSViRXqgySstTvHsEXOsI1gUdBAXnN3G+BDBR4RHENUauIDzNLuqgZN4VgNYZEspnMsdwPpE6WQRx7RHVTAe8Cc2LEwTRYSDBIgiCBIsgCIIEiyAIEiyCIAgSLIIgCBIsgiBIsAiCIEiwCIIgOoFgMdZ5YiE6UEF07irRKb3zCcHiHJyzpr9//9uTnI6PtwjkscdYa8RC+Ehxd7KUkHcdeEhYW+vJ44eS5TPhBgNvjVgIHynuzp0S8q4jCRZBEAQJFkEQHRt3Xi+jVIAxcA6T6PV0rFqF+nq5y3r4sCch6HRYuRJGIwfAGDIzWyUWwkeKu/OlhLxzBTZ73exPTm4XJ42CaP/FgIKA/AJkn4fOgEAV+iegf28H9sKOS+yT8xwzJGmLK+/DapBB99Lt/i2Er9Q5nym7zl2L2tW7TIViOAL9xE/Go85r/RtWWCK45PeZPBw5jRoDTECdESfO4fgZL66atlzOSE62uDJsmI1bCgrMBjt2sOhoJ6uEhI9Aq4TknccILvl9MhcS3p79ds3Gmk2Pb4IInLkEo7GV0lRby0VLURZtaXR1tfn/mhpu9WPidJWQ8BFolZC886pgXakCEBUWNf+W+TWGmukjpvfv0R8CUF5JjY0gCB8TLD8/cGiqNNpaLWPMJJryNHnggJ8fZR9BEG2JC6uEXYIQFojq2oGLBv5m5G++OfaNUTQiUI2IrraHah5htZxRWooVK2AycQBKJSspsXHLO+8gKkq+JSsLer3zVULCR6BVQvKu1QRLFHHzSKQeKtOWvZv6Ljjgp8T4UV5Uq5aUlmLx4qYhNwcwZQpGjWrq87H/+z/+zjsWY/IuXZwH+/rrrHn5ffed81sefhgJCfL/+fnYuBErV7KmCbI9e1BQgDlz5MxQqdiqVbz55JqL8bb07umnWXM53ratjZLqI7GMH4/x4+X/1Wq2eDGX3D/dbsYMDB7cNIPD3njDk0kcrxSNB7RNPreXdx7j2rYGAAoBxaXQ1yLAH/Hd4LD6uLutAQDnrFnXif/hD9YGa9fi6afNNoxZBxsbi+Jis8GcOXzjRrdjaUlqKiZMkO/6+Wc+caJFIEuX8rQ07NplvhIXxy9f9oJ32dls4ED549at/IEH2iipPpIhr76KV14x26hU3OT+8Xaff46ZM+VArlxBeDj3SsXzoGg8oANVPFu01rYGlzeOihK6Rcr/S3QCPUEQ7QA9mkMQBAnWVRAQwFy8aOGJpStqNfMglpYEBzOb/zcN+1Uq5iAZHnvXfEouMLB9ktqOGeLnZ3HRs03KzfMtNNRrFc+DovHZfG4v7zwfFbo6h+WWCvrkoznt9aSCB/EKQmcedvtOQXTuomlX79p9Dqs14dyTdbSWvwwLF7KmbQ1ffYXjx92OxSuLU069y8jAs8+ypk0bb7/NrfZtuBJp26yjtU2GtFJBOPXOK0XjtOK5gs9WPK9419l6WPCZVUKvLE459e6993DypPlKcjI/ccLtMNtmHa1tMsR3Vgk9KBpXKl7blKYvedeODz8TBEH4BiRYBEGQYF0F7bhK6JXFKafxKhQWV6w+ukjbrKO1TYa0l3deKRp3K17rlabPeudFfGIOy4O1iQ60vuOz60ot87Btkto2sbjiXedejW1X7zr1HJYkuf2msZZq5fSYL1dief111txGpWof71zh6pPKOXbsMIcgiqxl/W6vDGkb77xSNE4rXtuUZitVPK9418mHhO14zFfTGrA9WWwv71opqTU15tuqquA7GdI23rVLxWu90vRZ79pPsOj0ZIIg2g93No7mFUBXg8AAJPaAQMpFEIRvCpa+Fj+lQWrsDWadw8TRCAn2Yjp85JivPXvQtEqgVjNvzVm2xnvUvJLUL77A6dO8ccjAfCdD2sa7Nqt4bVOaPuudF3FhlVCpwI6fUW8YHD947k1ztxzekp6XDqWAeyfZW4Rog2cJPXG14zxL2G614RorCDrmq9Vox1XCK1rUGAQmHFp86OGxD+9buC84IBhGCZoKb6XDK+cROV3OcCWW1lisaaXTlrySVKt1tJb1u70ypG28a5uK12al6bPeeREXBMskAgj2D1Yr1QAEJkQGRzZdbw1oldAVaJXw6r1rl4rXeqXps961rWBFhIJBq9P+ccsfK/QVy7Yvu/DrBXAgKgwEQRBtiAuT7hLHiCSkn1r709q1362FCmDA9f2gUNBp8QRB+JhgAegVh6AAZOfK2xoGJCA22rvb/mmV0F1olfDqvQOtEraJd20uWJwjoituGQWBgXOIUmd9BGvPnoaqI7uNtjptqb2Sum1b83OcuO9kyNXHu2KFJ93/6GiLV9z98598xAjnB2EtWuQkLqcvLOxAFa996TAv8HNKhz7myyt0pmO+rj7e6Gi+du3VvsBvyBD+xBNeOAir41Y8eoEfQRCEp50hygKCIEiwPMfFA7isPenIx3x5hc50zNfVx8uYd17g5/WDsDpWxfO1F/j5xKk5jNk4VMJdioqcBOJZLKNG8RbhtLzS6t61TVJ9OUM8iHfqVG71bctHc2wFYnFl3jw+b55FA+7Rg7dB9faRiue0WV2LPay22c7VXpvGaLOazxaEBynxYHmcKl4nHxISBEGQYBEEQYJFEARBgkUQBEGCRRAECRZBEAQJFkEQBAkWQRAkWARBECRYBEGQYBEEQXQAWvXh5wY1pDOiCeJaQ92RBIsrGAMYSxWE8S6+cZQgiE6EHmBQer+z0jqCNS4GG3IADYOGio4grkk4n9ID9V4+/KF1hoTBKnHTLexoOSTqXhHENUlMAB/QFcYOIVgA/BR8TDSVGkFcuxi9f7YWrRISBNFhIMEiCIIEiyAIggSLIAgSLIIgCF/H/VVCgUFgAMDhxdPtCYIgvCdYjEHiyCpCYQUqayBxBPkhNhQDYxEWRMpFEITPCJZCwIEcHMxHPQYOHDh48DiVQlWgKfjl4C/Yk4d+4bhzCPxVlJsEQTgXk6YhmiS5u7fcBcESJXychpKaPz38p6Xzlgb5BzX/csvuLY+/+bj2vb2YOQLxXenBQYIgbA/RTCKyipBfhnIdJA61ArGhuK4b+sXAJHpJsBjDxjR/A45/ebZfj34tv3/w1gcfvPXBCc9O2PPZHswahegQKhqCICxlRsD+HKTlw4AbRtwwPGV4kH9QWWXZjxk/Fh05jvBs3DUEPSNc6W05FCyB4fssaOty/1MYHxXvwPDnf/488rGRGV9k4OmJVDoEQZjhwIY0XNa9OOfF5Y8t91P5Nf8y+0L2/NXzD3x6ADcn4Oa+MDmZDXe4raGyFpmX1724zrFaNZD6j1TUSUjLBaMXYBEEAQBQCPj0ECp0mZ9mrn5qtZVaARjUe9D+dfuXPLEE+/KRnu9UPQRHg8EjF/xC/J6c9qQrCesS2OWpmU/h6EUoBc99q63Hr2XQ6qBQUFkTRDvDAMZwRQtdjSdNkjHsz0GRLvOjzOTrkh0YLp23dMHDC/BTDq7oPRUspYA8zezbZ7uevLl3zUU1x69VHubOvgzs/AVpmfjxEP67FwYjVRiCaDcEAbmX8OWPSD2MXWnYkYpqvXshiBIO5i+ct9CxWjXw1jNvxcbFYvdpKBz1eOzPYXGO8vrRSaNdT96I/iMgARodIoLdzBqGQ8ehqYASk5MmHzx/UF+j56mHcM+tkGiHF0G0BxcKkXkOHEk9k4oqiyr1ldh9EFMnuNHVOl4AE16b/5qL5qufWj3rz7Ogr3ewR8q+YBlESAjrEuaekyp40jMySbhYCo7M1zMTIxMlLnVb0K2+rh7bvqMZMYJon8GgiYNh+YzlL9zxgsCElKUpWUVZyL2E/gkuhaAQkK8Zd8M4heCqwP1+8u9nvTwL+RoMjHNfsNQKMFTqKt3z0wio3X/cp7YWAhQqxeD4wZU1lX5Kv5G9R+7P2S939AiCaGMamp0J04ZP09frAdxz/T1ZRVnQ14Axl1qlwFChHzF2hBsiyVhk98iycj2Y3aMglA7uRoQ6/XT63ClzXYwvMzcTAtweDwIIDgIgGsQth7fMHDnzzOUz+8/tBwNUKuphEUT79LBqDVBh44GNK+9faRSNW9O3AkBwsKt9CAYYTCFB7m3M7BrUtcxQC/uKpXQ0TEuM2vzD5nV/WudiZJu+34RgIK4rjKLbGZSUiOy8h9556KmQp7RaLVRAZBgmjqY5LIJoH4pL8cuxv+786+aDm8t0ZSbRBMbQr6cbfTR/VXlVuVtxaqo0iA1zoIkOJ92H96pOT1u/c/0jdz3iNKZ6Q/1bn76FET2dbv2yHVfSdRAEnMrVVmshAD1jMTyJFgoJot2IicQNg5GR9WvFr+BA10CMHe7GMaMSR0SXQ9mHXI+wzlBX9WsVburhwMbhfFNEMIZEz1s1b+rYqZFdI5nDtE58biKUwE19PZx1EiX0742BfWAwQK2CxGn2iiDaE4mjewx6xUOrg0qJAH+Ionst+rqo9O3pWr3WxYHhv7/9N1RAH0eH1whOopwyFIHqxJmJl8suOzC8+6W7046mYfqIq5py4oAoQqGAKJFaEYRPIIoICoBa5Z5aNTA4HoF47p/PuWi+8L2FGBgFlcJTwWrg4bE6wRh/d/xfPvwLb6Ej3x74Nnpq9M59OzE9GfFhVL4EQZi7IBMGbNi24fv/fe/Udvri6TqdDpMGOX4Ems1eN/uTk9vFSaMcvYSPMfx8GhmFkDA6ZfTAXgP91f4XSy7uzthdr61Hj2BMTUZIAL1bhiAIC5QKfJmBnPKv3vzqvnH32bP63dLfffbtZ7h/KK5zNB5khSWuCRYAgcEgIqsQF8pRVQMO+CsRH4ZBcegW6vrrbAiCuLZQCPjmGLI090y+52/P/O26+Ouaf7njwI4n//pk0eUiTB2MAbFOuleFJS5v8pQ4lAKu74mU3mAMDOAcogQOUiuCIOwiSpg2HH2Ltqfu3D51e2RcZEr/lAD/AM0VzYETB1AH9ArBY2MRGnjV78OyFz1BEITrmET0j0FSHHJLy/LLdhUdhlFEoBo3JKJfN0SHwCS6uM6mpMwkCKJNZEtC70gkREFg8lb2ht6PO0M0EiyCINoQziF6vjxHB6kSBNFhaBIsesaYIAhfRwkAdfWn0TLpAAAAEklEQVTsZA6jzeUEQfgy1fr/B+D9qVeHBFjUAAAAAElFTkSuQmCC/9k=\" alt=\"Microclub\" /></div>"
        "<table>"
        "<tr><th>Bloc A</th><td><input type=\"checkbox\" onchange=\"changeState(this);\" id=\"blockA\" /></td></tr>"
        "<tr><th>Bloc B</th><td><input type=\"checkbox\" onchange=\"changeState(this);\" id=\"blockB\" /></td></tr>"
        "<tr><th>Bloc C</th><td><input type=\"checkbox\" onchange=\"changeState(this);\" id=\"blockC\" /></td></tr>"
        "<tr><th>Bloc D</th><td><input type=\"checkbox\" onchange=\"changeState(this);\" id=\"blockD\" /></td></tr>"
        "</table><script>"
        "function changeState(who){"
        "var xhr;try{xhr=new ActiveXObject('Msxml2.XMLHTTP');}catch(e0){"
        "try{xhr=new ActiveXObject('Microsoft.XMLHTTP');}catch(e1){"
        "try{xhr=new XMLHttpRequest();}catch(e2){xhr=false;}}}"
        "xhr.onreadystatechange=function(){"
        "if(xhr.readyState==4){if(xhr.status  == 200){}else{}}};"
        "var isChecked='0';if(who.checked){isChecked='1';}"
        "xhr.open('GET','/Command?'+who.id+'='+isChecked,true);"
        "xhr.send(null);"
        "}</script></body></html>";
  WEB_SERVER.send(200, "text/html", html);
}

/**
 *  Gesiton des requêtes AJAX
 */
void handleCommand() {
  Serial.println("Command request!");

  // Contrôle des arguments
  if(WEB_SERVER.hasArg("blockA")) {
    if(strcmp(WEB_SERVER.arg("blockA").c_str(), "1") == 0) {
      Serial.println("Block A: YELLOW\r\n");
      VRelais8 &= 0xFC;
      VRelais8|= 0x02;   
    } else {
      Serial.println("Block A: RED\r\n");
      VRelais8 &= 0xFC;
      VRelais8|= 0x01;
    }
    EcritMultout(0x20,0x12,VRelais8,VRelais16);
  } else if(WEB_SERVER.hasArg("blockB")) {
    if(strcmp(WEB_SERVER.arg("blockB").c_str(), "1") == 0) {
      Serial.println("Block B: YELLOW\r\n");
      VRelais8 &= 0xF3;
      VRelais8|= 0x08;
    } else {
      Serial.println("Block B: RED\r\n");
      VRelais8 &= 0xF3;
      VRelais8|= 0x04;
    }
    EcritMultout(0x20,0x12,VRelais8,VRelais16);
  } else if(WEB_SERVER.hasArg("blockC")) {
    if(strcmp(WEB_SERVER.arg("blockC").c_str(), "1") == 0) {
      Serial.println("Block C: YELLOW\r\n");
      VRelais8 &= 0xCF;
      VRelais8|= 0x20;
    } else {
      Serial.println("Block C: RED\r\n");
      VRelais8 &= 0xCF;
      VRelais8|= 0x10;
    }
    EcritMultout(0x20,0x12,VRelais8,VRelais16);
  } else if(WEB_SERVER.hasArg("blockD")) {
    if(strcmp(WEB_SERVER.arg("blockD").c_str(), "1") == 0) {
      Serial.println("Block D: YELLOW\r\n");
      VRelais8 &= 0x3F;
      VRelais8|= 0x80;
    } else {
      Serial.println("Block D: RED\r\n");
      VRelais8 &= 0x3F;
      VRelais8|= 0x40;
    }
    EcritMultout(0x20,0x12,VRelais8,VRelais16);
  }

  // Génération d'une valeur bidon afin d'éviter que les navigateurs
  // tournent en boucle (no response error)
  WEB_SERVER.send(200, "text/html", "0");
}


//
//  Routines
//

/**
 *  Initilisation
 */
void setup() {
  // Facultatif, mais par sécurité, laisser un délai afin que tous les
  // modules de l'ESP8266 puissent se charger
	delay(1000);
  

  // Initilaise l'UART (Laurent: contrôle des termes)
	Serial.begin(115200);
	Serial.println();
  // Initialisation de bus I2C et configuration de la carte MULTOUT
  Wire.begin();
  Serial.println("Wire begin");
  InitMCP23017(0x20,0,0); // MULTOUT A
  Serial.println("InitPort A");
  InitMCP23017(0x20,1,0);  // MULTOUT B
  Serial.println("InitPort B");
  VRelais8 = 0x55;
  VRelais16 = 0x55;
  EcritMultout(0x20,0x12,VRelais8,VRelais16);
	Serial.print("Configuration du WiFi en mode Access Point");

 
  // Configuration du WiFi
  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(SERVER_IP, SERVER_IP, IPAddress(255, 255, 255, 0));
	WiFi.softAP(SSID);
  Serial.println();
  Serial.println("Réseau WiFi Microclub (sans mot de passe) disponible.");
  Serial.println("Adresse IP: 192.168.1.1.");


  // Gestion du serveur DNS
  // On redirige toutes les requêtes à l'adresse du routeur
  DNS_SERVER.start(DNS_PORT, "*", SERVER_IP);
  Serial.println();
 Serial.println("Serveur DNS démarré");


  // Gestion du serveur web
	WEB_SERVER.on("/", handleRoot);
  WEB_SERVER.on("/Command", handleCommand);
  WEB_SERVER.onNotFound(handleRoot);
	WEB_SERVER.begin();
  Serial.println();
	Serial.println("Serveur web démarré");
}

/**
 *  Routines
 */
void loop() {
  // Toutes les requêtes doivent être traitée par le serveur DNS au préalable
  DNS_SERVER.processNextRequest();
  
  // Traite les requêtes des clients web
	WEB_SERVER.handleClient();
}
