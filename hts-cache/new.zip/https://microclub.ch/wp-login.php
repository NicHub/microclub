<!DOCTYPE html>
	<html lang="fr-FR">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Se connecter &lsaquo; Microclub &#8212; WordPress</title>
	<meta name='robots' content='max-image-preview:large, noindex, noarchive' />
<link rel='stylesheet' href='https://microclub.ch/wp-admin/load-styles.php?c=0&amp;dir=ltr&amp;load%5Bchunk_0%5D=dashicons,buttons,forms,l10n,wp-base-styles,wp-tooltip,login&amp;ver=7.1.3' media='all' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		</head>
	<body class="login no-js login-action-login wp-core-ui admin-color-modern locale-fr-fr">
	<script>
document.body.className = document.body.className.replace('no-js','js');
</script>

				<h1 class="screen-reader-text">Se connecter</h1>
			<div id="login">
		<h1 role="presentation" class="wp-login-logo"><a href="https://fr.wordpress.org/">Propulsé par WordPress</a></h1>
	
		<form name="loginform" id="loginform" action="https://microclub.ch/wp-login.php" method="post">
			<p>
				<label for="user_login">Identifiant ou adresse e-mail</label>
				<input type="text" name="log" id="user_login" class="input ltr" value="" size="20" autocapitalize="off" autocomplete="username" required="required" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">Mot de passe</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input ltr" value="" size="20" autocomplete="current-password" spellcheck="false" required="required" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Afficher le mot de passe">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
									<p class="forgetmenot">
				<input name="rememberme" type="checkbox" id="rememberme" value="forever"  />
				<label for="rememberme">Se souvenir de moi</label>
				<span class="wp-tooltip wp-is-toggletip">
				<button aria-haspopup="dialog" aria-label="Aide" class="wp-tooltip__toggle" popovertarget="rememberme-help-toggletip" type="button"><span aria-hidden="true" class="dashicons dashicons-editor-help"></span></button>
				<span popover="auto" id="rememberme-help-toggletip" class="wp-tooltip__bubble" role="dialog" aria-label="Aide" tabindex="-1" autofocus><span id="rememberme-help-toggletip-text" class="wp-tooltip__text">En sélectionnant « Se souvenir de moi », vous prolongez le délai avant que l’on vous demande de vous reconnecter sur cet appareil. Pour garantir la sécurité de votre compte, utilisez cette option uniquement sur vos appareils personnels.</span><button type="button" class="wp-tooltip__close" popovertarget="rememberme-help-toggletip" popovertargetaction="hide" aria-label="Fermer"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button></span></span>			</p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Se connecter" />
									<input type="hidden" name="redirect_to" value="https://microclub.ch/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
				<a class="wp-login-lost-password" href="https://microclub.ch/wp-login.php?action=lostpassword">Mot de passe oublié ?</a>			</p>
			<script>
function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }
</script>
		<p id="backtoblog">
			<a href="https://microclub.ch/">&larr; Aller sur Microclub</a>		</p>
			</div>
				<div class="language-switcher">
				<form id="language-switcher" method="get">

					<label for="language-switcher-locales">
						Langue<span class="dashicons dashicons-translation" aria-hidden="true"></span>
					</label>

					<select name="wp_lang" id="language-switcher-locales"><option value="en_US" lang="en" data-installed="1">English (United States)</option>
<option value="fr_FR" lang="fr" selected='selected' data-installed="1">Français</option></select>
					
					
					
						<input type="submit" class="button" value="Modifier">

					</form>
				</div>
			
	<script>
var _zxcvbnSettings = {"src":"https://microclub.ch/wp-includes/js/zxcvbn.min.js"};
//# sourceURL=js-inline-concat-clipboard%2Cjquery-core%2Cjquery-migrate%2Czxcvbn-async%2Cwp-hooks
</script>
<script src="https://microclub.ch/wp-admin/load-scripts.php?c=0&#038;load%5Bchunk_0%5D=clipboard,jquery-core,jquery-migrate,zxcvbn-async,wp-hooks&#038;ver=7.1.3"></script>
<script id="wp-i18n-js" src="https://microclub.ch/wp-includes/js/dist/i18n.min.js?ver=1dfe7db3940c23ea9216"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
</script>
<script id="password-strength-meter-js-extra">
var pwsL10n = {"unknown":"Force du mot de passe inconnue.","short":"Tr\u00e8s faible","bad":"Faible","good":"Moyenne","strong":"Forte","mismatch":"Non concordance"};
//# sourceURL=password-strength-meter-js-extra
</script>
<script id="password-strength-meter-js-translations">
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2026-08-20 16:47:50+0000","generator":"GlotPress\/4.1.0","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=2; plural=n > 1;","lang":"fr"},"%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.":["%1$s est obsol\u00e8te depuis la version %2$s\u00a0! Utilisez %3$s \u00e0 la place. Pensons \u00e0 \u00e9crire du code plus inclusif."]}},"comment":{"reference":"wp-admin\/js\/password-strength-meter.js"}} );
//# sourceURL=password-strength-meter-js-translations
</script>
<script id="password-strength-meter-js" src="https://microclub.ch/wp-admin/js/password-strength-meter.min.js?ver=7.1.3"></script>
<script id="underscore-js" src="https://microclub.ch/wp-includes/js/underscore.min.js?ver=1.13.8"></script>
<script id="wp-util-js-extra">
var _wpUtilSettings = {"ajax":{"url":"/wp-admin/admin-ajax.php"}};
//# sourceURL=wp-util-js-extra
</script>
<script id="wp-util-js" src="https://microclub.ch/wp-includes/js/wp-util.min.js?ver=7.1.3"></script>
<script id="wp-dom-ready-js" src="https://microclub.ch/wp-includes/js/dist/dom-ready.min.js?ver=3fe927cab37bf38d6a23"></script>
<script id="wp-a11y-js-translations">
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2026-10-07 20:18:27+0000","generator":"GlotPress\/4.1.0","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=2; plural=n > 1;","lang":"fr"},"Notifications":["Notifications"]}},"comment":{"reference":"wp-includes\/js\/dist\/a11y.js"}} );
//# sourceURL=wp-a11y-js-translations
</script>
<script id="wp-a11y-js" src="https://microclub.ch/wp-includes/js/dist/a11y.min.js?ver=31c6cec5a4ff7aff483d"></script>
<script id="user-profile-js-extra">
var userProfileL10n = {"user_id":"0","nonce":"06340120d2"};
//# sourceURL=user-profile-js-extra
</script>
<script id="user-profile-js-translations">
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2026-08-20 16:47:50+0000","generator":"GlotPress\/4.1.0","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=2; plural=n > 1;","lang":"fr"},"Caps lock is on.":["Le verrouillage majuscule est activ\u00e9."],"Application password has been copied to your clipboard.":["Le mot de passe d\u2019application a \u00e9t\u00e9 copi\u00e9 dans votre presse-papier."],"Your new password has not been saved.":["Votre nouveau mot de passe n\u2019a pas \u00e9t\u00e9 enregistr\u00e9."],"Confirm use of weak password":["Confirmer l\u2019utilisation du mot de passe faible"],"Hide password":["Masquer le mot de passe"],"Show password":["Afficher le mot de passe"],"Hide":["Masquer"],"Show":["Afficher"],"The changes you made will be lost if you navigate away from this page.":["Les modifications que vous avez faites seront perdues si vous changez de page."]}},"comment":{"reference":"wp-admin\/js\/user-profile.js"}} );
//# sourceURL=user-profile-js-translations
</script>
<script id="user-profile-js" src="https://microclub.ch/wp-admin/js/user-profile.min.js?ver=7.1.3"></script>
<script id="wp-tooltip-js" src="https://microclub.ch/wp-includes/js/wp-tooltip.js?ver=7.1.3"></script>
	</body>
	</html>
	